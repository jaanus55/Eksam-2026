﻿AS ÕIGE – AD/DNS/DHCP/GPO PRAKTILISE TÖÖ FAILID

Failid
=====
1. kasutajad.csv
   Näidisandmed kasutajate importimiseks.
   Veerud: Eesnimi;Perenimi;Kasutajanimi;Parool;OU;Osakond

2. Import-ADUsers.ps1
   Loob CSV-s kirjeldatud OU-struktuuri ja kasutajakontod.

3. AD-Kontode-Raport.ps1
   Koostab raporti:
   - kunagi domeeni logimata kontodest;
   - keelatud kontodest;
   - lukustatud kontodest.

4. DHCP-Raport.ps1
   Koostab raporti:
   - DHCP teenuse olekust;
   - aktiivsetest skoopidest;
   - failover-olekust;
   - kasutuses olevatest IP- ja MAC-aadressidest;
   - reserveeringutest;
   - vabadest IP-aadressidest.

Kasutamine
==========
1. Kopeeri kaust DC1 serverisse, näiteks C:\AS-Oige.
2. Ava Windows PowerShell administraatorina.
3. Vajadusel luba skripti käivitamine ainult selles aknas:
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
4. Kasutajate import:
   cd C:\AS-Oige
   .\Import-ADUsers.ps1
5. AD raport:
   .\AD-Kontode-Raport.ps1
6. DHCP raport:
   .\DHCP-Raport.ps1 -DhcpServer DC1

Märkus
======
Näidis kasutab domeeni DNS-nime automaatselt. Seetõttu töötab import nii salm.local
kui ka mõne muu sinu loodud sinuninimi.local domeeniga.

CSV-s olevad paroolid on laboriülesande lihtsustamiseks avatekstina. Tootmiskeskkonnas
ei tohiks paroole niimoodi säilitada.
